# Project Assignment POO  - J. POO Morgan - Phase One
# Enea Vlad Mihai - Grupa 325CD

    Acest proiect incepe din clasa Bank. Acolo se iau toti userii de la input si dupa aceea 
prin metoda actions se verifica comenzile din input si se executa. Eu am facut acest pana la 
testul 17, adica toate comenzile in afara de SpendingReport.
    Design Patterns folosite: Singleton, Factory.
    Singleton: am folosit Singleton pentru a crea o singura instanta a clasei Account, PayOnline
si sendMoney.
    Factory: am folosit Factory pentru a crea un cont de tipul dorit.  La account am
folosit si genericitate. De asemenea am tinut cont de tipul contului creat: clasic sau economii.
    Comenzi facute: AddAccount, AddFunds, CheckCardStatus, CreateCard, CreateOneTimeCard,
DeleteAccount, DeleteCard, PayOnline, PrintTransactions, PrintUsers, Report, SendMoney,
SetAlias, SetMinBalance, SplitPayments.
    Ierarhie fisiere: Pachetul Bank contine toata tema, mi s-a parut cel mai sugestiv nume.
Banca lucreaza cu useri, asadar in pachetul userInfo avem toate aceste informatii: useri,
conturi, carduri si tranzactii. In pachetul userInfo se afla si pachetul accountType in care
doar se face diferenta dintre cele 2 tipuri de conturi: clasic si economii.
    In pachetul Bank se mai afla si pachetul commands in care se afla toate comenzile pe care
le-am avut de implementat. In commands se mai afla pachetul factoryDesing unde am implementat
factory.
    