package org.poo.bank.commands.factoryDesign;

public enum AccountTypes {
    Classic,
    Savings
}
